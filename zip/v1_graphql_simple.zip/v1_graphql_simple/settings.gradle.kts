rootProject.name = "v1_graphql_simple"
