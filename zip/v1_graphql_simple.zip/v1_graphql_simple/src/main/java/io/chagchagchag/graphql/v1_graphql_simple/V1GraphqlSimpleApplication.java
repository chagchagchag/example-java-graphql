package io.chagchagchag.graphql.v1_graphql_simple;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class V1GraphqlSimpleApplication {

	public static void main(String[] args) {
		SpringApplication.run(V1GraphqlSimpleApplication.class, args);
	}

}
