package io.chagchagchag.graphql.v1_graphql_simple;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class V1GraphqlSimpleApplicationTests {

	@Test
	void contextLoads() {
	}

}
